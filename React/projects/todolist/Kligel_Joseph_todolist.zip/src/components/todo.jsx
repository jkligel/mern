import React, {useState} from 'react';
import '../App.css'

const Todo = (props) => {
    
    const [newTodo, setNewTodo] = useState("");
    const [todos, setTodos] = useState([]);

    return(
        <p>{ }</p>
    )
} 

export default Todo;