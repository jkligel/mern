import React from 'react';
import UserForm from './components/user_form.js';
import './App.css'

function App(props){

  return (
    <div className="App">
      <UserForm className="UserForm" />
    </div>
  )

}

export default App;